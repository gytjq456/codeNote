<? include $_SERVER['DOCUMENT_ROOT']."/inc/header.php"; ?>
<!--main start-->

<!--main end-->
<? include $_SERVER['DOCUMENT_ROOT']."/inc/footer.php"; ?>


