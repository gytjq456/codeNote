		<?  if ($file != "index.php") { ?>
					</div><!--subContents-->
				</div><!--#subWrap-->
		<? } ?>
		<footer>

		</footer>
	</div><!--#wrap-->
</body>
</html>