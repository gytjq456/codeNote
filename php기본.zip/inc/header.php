<!DOCTYPE HTML>
<html lang="ko">

<head>
	<title>타이틀</title>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<!--meta name="viewport" content="width=device-width,user-scalable=no,initial-scale=1.0,maximum-scale=1.0,minimum-scale=1.0,user-scalable=no"-->
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1" />
	<meta name="format-detection" content="telephone=no" />
	<meta name="keywords" content="">
	<meta name="Description" content="">
	<meta property="og:image" content="이미지 주소" />
	<meta name="google" value="notranslate" />
	<link rel=" shortcut icon" href="파일이름.ico">
	<link rel="icon" href="파일이름.ico">
	<link rel="stylesheet" type="text/css" href="/css/style.css" />
	<link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css" />
	<script type="text/javascript" src="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>
	<script src="http://code.jquery.com/jquery-latest.js"></script>
	<script src="/js/common.js"></script>
	<!--[if lt IE 9]>
		<script src="/js/html5shiv.js"></script>
		<![endif]-->

	<script type="text/javascript">
	function updateOrientation() {
		var orientationValue = window.orientation
		if (orientationValue == 90 || orientationValue == -90) {
			$("meta[name=viewport]").attr("content",
				"width=device-width, initial-scale=1.0, maximum-scale=2.5, minimum-scale=1.0, user-scalable=yes,target-densitydpi=medium-dpi"
			);
		}
	}

	window.onload = function() {
		document.body.onorientationchange = updateOrientation;
	}

	var windowWidth = window.innerWidth
	setViewPort(windowWidth);

	function setViewPort(w_width) {
		if (w_width <= 400) {
			$("meta[name=viewport]").attr("content",
				"width=400, maximum-scale=2.0, user-scalable=yes, target-densitydpi=medium-dpi");
		} else {
			$("meta[name=viewport]").attr("content",
				"width=device-width, initial-scale=1.0, maximum-scale=2.5, minimum-scale=1.0, user-scalable=yes,target-densitydpi=medium-dpi"
			);
		}
	}

	$(window).resize(function() {
		windowWidth = window.innerWidth
		setViewPort(windowWidth);
	})
	</script>

</head>

<body>
	<div id="wrap">
		<header>

		</header>
		<? $file = basename($_SERVER["SCRIPT_NAME"]);
	$folderName = explode("/",$_SERVER["SCRIPT_NAME"]);
	switch( $folderName[3]){
		case "company" : 
		$num = 1; 
		$sv01 = "COMPANY";
		break;
		case "product" : 
		$num = 2; 
		$sv01 = "PRODUCT";
		break;
		case "news" : 
		$num = 3; 
		$sv01 = "NEWS";
		break;
	}
	if ($file != "index.php") { ?>
		<script>
		$(function() {
			var depth2 = $("#gnb > li:eq(" + (<?=$num?> - 1) + ") .depth2").clone();
			$lnb = $("#lnb");
			$lnb.children("div").append(depth2);

			function getParameter(name) {
				name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
				var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
					results = regex.exec(location.search);
				return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
			}
			var s_cate = getParameter("s_cate").toUpperCase();
			if (s_cate) {
				$lnb.find("li").each(function(index, item) {
					var menu = $(this).text().toUpperCase().trim();
					// if (menu.indexOf(s_cate) >= 0) {
					if (menu == s_cate) {
						$(this).addClass("on");
					}
				});
			} else {
				$lnb.find("li").each(function(index, item) {
					var hrefVal = $(this).find("a").attr("href");
					var url = location.href;
					var hrefVlaArr = hrefVal.split("/");
					var hrefVlaArrMenu = hrefVlaArr[hrefVlaArr.length - 1].split(".asp")[0];
					var urlSplit = url.split(".asp")[0].split("/");
					var currentMenu = urlSplit[urlSplit.length - 1];
					if (hrefVlaArrMenu == currentMenu) {
						$(this).addClass("on");
					}
				})
			}

		})
		</script>


		<div id="subWrap">
			<section id="sv" class="sv0<?=$mNum?>">
				<div class="inner">
					<dl>
						<dt><?=$sv01?></dt>
						<dd>Leading Solution Provider for EUV Lithography</dd>
					</dl>
				</div>
			</section>
			<!--#sv-->
			<section id="lnb" class="sm<?=$mNum?>">
				<div class="inner">

				</div>
			</section>
			<div id="subContents">
				<div class="subTitle"><?=$subTitle?></div>

				<? } else { ?>
				<? } ?>